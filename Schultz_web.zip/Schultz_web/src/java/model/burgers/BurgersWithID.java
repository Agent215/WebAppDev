/*
This class will be good for web user update - provides a single web user plus the list of user Roles (for pick list).
 */
package model.burgers;

import model.webUser.*;

public class BurgersWithID {
    
    public model.burgers.StringData burger = new model.burgers.StringData();
    public model.webUser.StringDataList userInfo =  new model.webUser.StringDataList();

    
}